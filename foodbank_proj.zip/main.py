gcloud builds submit --tag gcr.io/my-scraper-456403/foodbank
gcloud run deploy foodbank \
  --image gcr.io/my-scraper-456403/foodbank \
  --region us-central1 \
  --no-allow-unauthenticated